
import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "libreria.settings")
django.setup()

from catalogo.models import Libro

# Lista de libros para cargar
libros = [
    {"titulo": "El principito", "autor": "Antoine de Saint-Exupéry", "genero": "Fábula"},
    {"titulo": "La Odisea", "autor": "Homero", "genero": "Épico"},
    {"titulo": "Rayuela", "autor": "Julio Cortázar", "genero": "Ficción"},
]

for dato in libros:
    Libro.objects.create(**dato)

print("Libros cargados exitosamente.")

