import pandas as pd
datos = {
"Nombre": ["Ana", "Luis", "Carlos"],
"Edad": [23, 25, 22],
"Ciudad" : ["Bogotá", "Cali", "Medellín"]
}
df = pd.DataFrame(datos)

print("\n dataframe completo\n",datos)
print (df.drop("Edad", axis=1))  # se eliina la edad
print ( df.drop(1))  # con drop se elimina la columna 1 

