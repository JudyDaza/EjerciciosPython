# concatenacion de DataFrames 
import pandas as pd 
# Definir el diccionario de productos 

productos = {
"Producto": ["Laptop", "Tablet", "Smartphone"],
"Precio": [800, 300, 600],
"Stock": [20, 50, 30]
}
#DataFrame1 con la informacion de productos
df1= pd.DataFrame (productos)

#DataFrame2 con la informacion de ventas
df2= pd.DataFrame ({ 
"Producto": ["Laptop", "Tablet", "Smartphone"],
"Unidades Vendidas": [5, 10, 8]
})

#concatena df1 y df2 uniendo por columnas
df_concat = pd.concat([df1, df2["Unidades Vendidas"]], axis=1)
print("\nUsando pd.concat para unir por columnas:")
print(df_concat)

# Usando pd.merge: Unir por la columna común 'Producto'
df_merge = pd.merge(df1, df2, on="Producto")
print("\nUsando pd.merge para unir por la columna 'Producto':")
print(df_merge)


# Concatenar por filas (una debajo de la otra)
df_concat = pd.concat([df1, df2], axis=0) # Esto funciona pero no tiene relación directa entre filas
print(" Concat por filas:\n", df_concat)

 #Nota: No tiene sentido semántico aquí, porque las columnas no coinciden. Solo se pegan uno debajo del otro.


# Merge usando la columna "Producto"
df_merge = pd.merge(df1, df2, on="Producto")
print(" Merge por columna Producto:\n", df_merge)


# Establecer "Producto" como índice para hacer join
df2_indexed = df2.set_index("Producto")

# Join desde df1 (por Producto)
df_join = df1.join(df2_indexed.set_index("Producto"), on="Producto")
print(" Join por índice:\n", df_join)