# DataFrames: creación y acceso  datos(nombre y edad)
import pandas as pd 
datos = {
"Nombre": ["Ana", "Luis", "Carlos"],
"Edad": [23, 25, 22]
}
df = pd.DataFrame(datos)
print(df["Nombre"])
print(df.iloc[1])
print(df.at[0, "Edad"])


libros =  {
"titulo": ["persuacion", "orgullo y prejuicio", "100 años de soledad"],
"autor": ["Jane Austen ", "Jane Austen", "Gabriel Garcia Marquez"],
"año":[1817, 1813, 1967]
}

dflibros=pd.DataFrame(libros)

print("\n dataframe completo\n",dflibros) # Esta linea de codigo con n significa un salto de linea  esto es una ayuda visual
print("\n columna de autores \n",dflibros ["autor"])
print("\n segunda columna \n",dflibros.iloc [1])
print("\n año libro \n",dflibros.at [0, "año"])
