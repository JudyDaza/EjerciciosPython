# Series y listas 

import pandas as pd 

lista= ["Blue ", "Red", "green", "orange"] 
serie= pd.Series (lista) #Se convierte se lista a serie 

# Acceder al segundo elemento de la serie 
elemento = serie [1] 

print ("Serie: ") # imprima en pantalla 
print (serie)
print (elemento)

