# introduccion y carga de datos
import pandas as pd 
lista = ["Mango", "Mandarina", "Pera", "durazno"] 
print (lista)

# Cargar un archivo .CSV 
df = pd.read_csv("libro1.csv")
print (df.head())