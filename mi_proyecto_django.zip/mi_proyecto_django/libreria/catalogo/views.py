# Create your views here.
from django.shortcuts import render
from .models import Libro
def lista_libros(request):
   libros = Libro.objects.all()
   return render(request, 'catalogo/lista.html', {'libros': libros})

def detalle_libros(request):
    libros = Libro.objects.prefetch_related('resena_set').select_related('editorial')
    return render(request, 'catalogo/detalle_libros.html', {'libros': libros})

