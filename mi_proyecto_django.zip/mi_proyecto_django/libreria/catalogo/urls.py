from django.urls import path
from . import views
urlpatterns = [
    path('', views.lista_libros, name='inicio'),
    path('libros/', views.lista_libros, name='lista_libros'),
]

from django.urls import path
from . import views
urlpatterns = [
path('', views.lista_libros, name='inicio'),
path('libros/', views.lista_libros),
path('detalle/', views.detalle_libros), # ← Nueva ruta
]