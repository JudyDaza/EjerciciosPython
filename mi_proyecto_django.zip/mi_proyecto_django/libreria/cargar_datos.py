from catalogo.models import Editorial, Libro, Resena
# Borrar datos previos (opcional)
Resena.objects.all().delete()
Libro.objects.all().delete()
Editorial.objects.all().delete()
# Crear Editoriales
e1 = Editorial.objects.create(nombre="Alfaguara", pais="España")
e2 = Editorial.objects.create(nombre="Sudamericana", pais="Argentina")
# Crear Libros (asociados a editoriales)

l1 = Libro.objects.create(
    titulo="Cien Años de Soledad", 
    autor="Gabriel García Márquez",
    genero="Realismo mágico", 
    editorial=e2)
l2 = Libro.objects.create(
    titulo="La Sombra del Viento", 
    autor="Carlos Ruiz Zafón",
    genero="Misterio", 
    editorial=e1)
# Crear Reseñas (asociadas a libros)
Resena.objects.create(
    libro=l1, 
    texto="Una obra maestra de la literatura latinoamericana.",
    puntuacion=5
)
Resena.objects.create(
    libro=l1, 
    texto="Un poco confuso al principio, pero genial.",
    puntuacion=4
)
Resena.objects.create(
    libro=l2, 
    texto="Narrativa envolvente y personajes memorables.",
    puntuacion=5
)
print(" Datos insertados correctamente.")