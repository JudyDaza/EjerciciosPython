
import os
import subprocess
import sys
def check(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.stdout.strip()
    except Exception as e:
        return str(e)
print(" Verificando entorno...")
print("Python:", sys.version)
print("Pip:", check("pip --version"))
django_version = check("django-admin --version")
if "not found" in django_version or "No se reconoce" in django_version:
    print(" Django NO está instalado.")
else:
    print(" Django:", django_version)
if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
    print(" Entorno virtual ACTIVADO.")
else:
    print(" Entorno virtual NO activado.")